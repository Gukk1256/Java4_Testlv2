package app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
//import javax.persistence.TypedQuery;
import entities.User; 
public class JpaProgram {
	private static void create() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("ffff");

		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			User entity = new User();
			entity.setId("Teo2");
			entity.setFullname("HUydang");
			entity.setEmail("huyh@gmail.com");
			entity.setPassword("123456");
			em.persist(entity);
			em.getTransaction().commit();
			System.out.println("Thanh Cong");
		} catch (Exception e) {

			em.getTransaction().rollback();
			System.out.println("That bai");
		}
		em.close();
		emf.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		create();
	}
}
