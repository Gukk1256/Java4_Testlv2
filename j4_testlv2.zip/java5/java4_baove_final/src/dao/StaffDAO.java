package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import entity.Staff;



public class StaffDAO {

	private EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
	private EntityManager em = emf.createEntityManager();

	protected void finalize() throws Throwable {
		em.close();
		emf.close();

	}

	public Staff create(Staff entity) {

		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction

			em.persist(entity);// Create
			em.getTransaction().commit(); // Chấp nhận kết quả thao tác

			return entity;
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback(); // Hủy thao tác
			throw new RuntimeException(e);

		}

	}

	public Staff update(Staff entity) {

		try {

			em.getTransaction().begin();

			em.merge(entity);

			em.getTransaction().commit();
			return entity;
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback(); // Hủy thao tác
			throw new RuntimeException(e);
		}

	}

	public Staff remove(String id) {

		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction

			Staff entity = em.find(Staff.class, id);
			// 6. xóa đối tượng đó đi
			em.remove(entity);

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			return entity;

		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback(); // Hủy thao tác
			throw new RuntimeException(e);
		}

	}
	
	public Staff findbyID(String id) {
		
		return em.find(Staff.class, id);

	}

	public List<Staff> findAll() {
		String jpql = "SELECT o FROM User o";
		TypedQuery<Staff> query = em.createQuery(jpql, Staff.class);
		return query.getResultList();

	}

	

	

}
