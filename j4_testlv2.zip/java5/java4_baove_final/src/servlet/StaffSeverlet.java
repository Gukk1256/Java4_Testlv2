package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import dao.StaffDAO;
import entity.Staff;



/**
 * Servlet implementation class UserServlet
 */
@WebServlet({ "/user/index", "/user/create", "/user/update", "/user/delete", "/user/resert", "/user/edit",
		"/user/delete/*", })
public class StaffSeverlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StaffSeverlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = req.getRequestURL().toString();
		req.setCharacterEncoding("utf-8");
		
		Staff user = null;

		if (url.contains("delete")) {
			StaffDAO dao = new StaffDAO();
			if (req.getParameter("id") != null) {
				dao.remove(req.getParameter("id"));
				req.setAttribute("message", "Delete sucsess!");

			}
		} else if (url.contains("edit")) {
			StaffDAO dao = new StaffDAO();
			if (req.getParameter("id") != null) 
				user = dao.findbyID(req.getParameter("id"));
			
				req.setAttribute("user", user);
			

		} else if (url.contains("resert")) {
			user = new Staff();
			req.setAttribute("user", user);
		}

		findAll(req, resp);
		
		req.getRequestDispatcher("/view/user.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = req.getRequestURL().toString();
		req.setCharacterEncoding("utf-8");
		Staff user = new Staff();
		if (url.contains("create")) {
			create(req, resp);
		} else if (url.contains("update")) {
			update(req, resp);
		} else if (url.contains("delete")) {
			delete(req, resp);
		} else if (url.contains("resert")) {
			req.setAttribute("user", new Staff());
		}
		findAll(req, resp);
		req.getRequestDispatcher("/view/user.jsp").forward(req, resp);
	}

	private void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			Staff user = new Staff();
			BeanUtils.populate(user, req.getParameterMap());
			StaffDAO dao = new StaffDAO();
			if (user.getId() != null) {
				dao.remove(user.getId());
			}
			req.setAttribute("message", "Delete success!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			req.setAttribute("error", "Error" + e.getMessage());
		}
	}

	private void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			Staff user = new Staff();
			BeanUtils.populate(user, req.getParameterMap());
			StaffDAO dao = new StaffDAO();
			dao.update(user);
			req.setAttribute("message", "Update success!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			req.setAttribute("error", "Error" + e.getMessage());
		}
	}

	private void create(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		try {
			Staff user = new Staff();
			BeanUtils.populate(user, req.getParameterMap());
			StaffDAO dao = new StaffDAO();
			dao.create(user);
			req.setAttribute("message", "Create success!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			req.setAttribute("error", "Error" + e.getMessage());
		}

	}

	protected void findAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			StaffDAO dao = new StaffDAO();
			List<Staff> list = dao.findAll();
			req.setAttribute("users", list);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			req.setAttribute("error", "Error" + e.getMessage());
		}
	}

}
