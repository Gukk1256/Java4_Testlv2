package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import entities.User;
import utils.JpaUtils;



public class UserDao {
	private  EntityManager em = JpaUtils.getEntityManager();

	@Override
	protected void finalize() throws Throwable {
		em.close();
		super.finalize();
	}

//	public  void create() {
//		// Táº¡o Entity
//		User entity = new User();
//		entity.setId("TeoNV");
//		entity.setFullname("Nguyá»…n VÄƒn TÃ¨o");
//		entity.setEmail("teonv@gmail.com");
//		entity.setPassword("123456");
//		// Insert vÃ o CSDL
//		em.persist(entity);
//		
//		
//	}
	public void create(User entity) {
		try {
			em.getTransaction().begin(); // Báº¯t Ä‘áº§u Transaction
			em.persist(entity);
			// MÃƒ THAO TÃ�C
			em.getTransaction().commit(); // Cháº¥p nháº­n káº¿t quáº£ thao tÃ¡c

		} catch (Exception e) {
			em.getTransaction().rollback(); // Há»§y thao tÃ¡c
			System.out.println("ThÃªm má»›i tháº¥t báº¡i!");
		}
	}

	public void update(User entity) {
		try {
			em.getTransaction().begin(); // Báº¯t Ä‘áº§u Transaction
			em.merge(entity);
			// MÃƒ THAO TÃ�C
			em.getTransaction().commit(); // Cháº¥p nháº­n káº¿t quáº£ thao tÃ¡c

		} catch (Exception e) {
			em.getTransaction().rollback(); // Há»§y thao tÃ¡c
			System.out.println("ThÃªm má»›i tháº¥t báº¡i!");
		}

	}

	public void remove(String id) {
		try {
			User entity = this.findById(id);
			em.getTransaction().begin(); // Báº¯t Ä‘áº§u Transaction
			em.remove(entity);
			// MÃƒ THAO TÃ�C
			em.getTransaction().commit(); // Cháº¥p nháº­n káº¿t quáº£ thao tÃ¡c

		} catch (Exception e) {
			em.getTransaction().rollback(); // Há»§y thao tÃ¡c
			System.out.println("ThÃªm má»›i tháº¥t báº¡i!");
		}

	}

	public User findById(String id) {
		User entity = em.find(User.class, id);
		return entity;
	}

	public List<User> findAll() {
		String jpql = "SELECT o FROM User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		List<User> list = query.getResultList();
		return list;
	}
	
	public User checkLogin(String username, String password) {
//		User kq = null;
		try {
			String jpql = "SELECT o FROM User o WHERE o.id = :username and o.password=:password";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("username", username);
			query.setParameter("password", password);

			return query.getSingleResult();
		} catch (Exception e) {
			//return null;
		}
		return null;
	}
}
