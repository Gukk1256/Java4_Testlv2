package controller;

import dao.UserDao;
import entities.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name ="LoginServlet", urlPatterns= {"/view/LoginServlet"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.getRequestDispatcher("/view/sign-in.jsp").forward(req, resp);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		String id = req.getParameter("username");
		String pw = req.getParameter("password");

		try {
			UserDao dao = new UserDao();
			User user = dao.checkLogin(id,pw);
			if (user != null) {
				HttpSession session = req.getSession();
				session.setAttribute("user", user.getId());
//				req.getRequestDispatcher("VideoServlet").forward(req, resp);
				resp.sendRedirect("VideoServlet");
			} else {
				req.getRequestDispatcher("/view/fail.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			req.setAttribute("message", "Sai tÃªn Ä‘Äƒng nháº­p!");
			req.getRequestDispatcher("/view/fail.jsp").forward(req, resp);
		}
		
	}
}
