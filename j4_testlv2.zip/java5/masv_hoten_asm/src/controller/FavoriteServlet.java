package controller;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.FavoriteDao;
import dao.VideoDao;
import utils.JpaUtils;

/**
 * Servlet implementation class FavoriteServlet
 */
@WebServlet(name = "FavoriteServlet", urlPatterns= { "/view/FavoriteServlet" })
public class FavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userid = req.getParameter("userid");
		String videoid = req.getParameter("videoid");
		FavoriteDao dao = new FavoriteDao();
		if (dao.isLike(userid, videoid)) {
			dao.unLike(userid, videoid);
		} else {
			dao.saveLike(userid, videoid);
		}
		resp.sendRedirect("VideoServlet");
	}

	EntityManager em = JpaUtils.getEntityManager();
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.getRequestDispatcher("/view/index.jsp").forward(req, resp);
	}

}
