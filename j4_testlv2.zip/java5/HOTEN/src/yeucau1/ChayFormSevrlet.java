package yeucau1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import yeucau1.Staff;
import yeucau1.StaffDAO;



/**
 * Servlet implementation class ChayFormSevrlet
 */
@WebServlet("/staff")
public class ChayFormSevrlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChayFormSevrlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/view/staff.jsp").forward(req, resp);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		String fullname = req.getParameter("fullname");
		String email = req.getParameter("email");
		boolean admin = Boolean.parseBoolean(req.getParameter("admin"));
		String action = req.getParameter("Action");
		
		
		Staff entity = new Staff();
		entity.setId(id);
		entity.setPassword(password);
		entity.setFullname(fullname);
		entity.setEmail(email);
		entity.setAdmin(admin);
		
		
		
		StaffDAO dao = new StaffDAO();
		Staff kq = null;

		if(action.equals("insert"))
		{
			 kq = dao.create(entity);
		}
		else if (action.equals("update"))
		{
			 kq = dao.update(entity);
		}
		else if (action.equals("delete"))
		{
			 kq = dao.remove(id);
		}
	
		if (kq == null)
			req.getRequestDispatcher("/view/fail.jsp").forward(req, resp);
		else
			req.getRequestDispatcher("/view/success.jsp").forward(req, resp);
	}

}
