package yeucau1;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;




public class StaffDAO {
	public Staff create(Staff entity ) {
		Staff kq = new Staff();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();		
		try {
			em.getTransaction().begin(); 
			em.persist(entity);
			em.getTransaction().commit(); 
			System.out.println("Thêm mới thành công!");
			kq = entity;
		} catch (Exception e) {
		
			em.getTransaction().rollback(); 
			System.out.println("Thêm mới thất bại!");
			kq = null;
		}
		em.close();
		emf.close();
		return kq;
	}
	
	public Staff update(Staff entity) {
		Staff kq = null;
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();		
		try {
			em.getTransaction().begin(); 
			em.merge(entity);
			em.getTransaction().commit(); 
			System.out.println("Cập nhật thành công!");
			kq = entity;
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Cập nhật thất bại!");
			kq = null;
		}

		em.close();
		emf.close();
		return kq;
	}

	public Staff remove(String id) {

		Staff kq = null;
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");

		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); 

			Staff entity = em.find(Staff.class, id);
			em.remove(entity);
			em.getTransaction().commit();
			System.out.println("Xóa thành công!");
			kq = entity;
		} catch (Exception e) {
			em.getTransaction().rollback(); 
			System.out.println("Xóa thất bại!");
			kq = null;
		}
		em.close();
		emf.close();
		return kq;
	}
	public void findAll() {


		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); 
			String jpql = "SELECT o FROM User o";
			// 6. Tạo đối tượng truy vấn
			TypedQuery<Staff> query = em.createQuery(jpql, Staff.class);
			// 7. Truy vấn
			List<Staff> list = query.getResultList();
			// 8. Hiển thị kết quả truy vấn
			for (Staff staff : list) {
				System.out.println(">>Fullname: " + staff.getFullname());
				System.out.println(">>Is Admin: " + staff.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findByRole(boolean role) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.admin=:role";
			// Tạo đối tượng truy vấn
			TypedQuery<Staff> query = em.createQuery(jpql, Staff.class);
			query.setParameter("role", role);
			// Truy vấn
			List<Staff> list = query.getResultList();
			// Hiển thị kết quả truy vấn

			// 8. Hiển thị kết quả truy vấn
			for (Staff user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
		
			em.getTransaction().rollback();
			System.out.println(" thất bại!");
		}

		em.close();
		emf.close();

	}

	public void findByKeyword(String keyword) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");

		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.fullname LIKE ?0";
			// Tạo đối tượng truy vấn
			TypedQuery<Staff> query = em.createQuery(jpql, Staff.class);
			query.setParameter(0, keyword);
			// Truy vấn
			List<Staff> list = query.getResultList();
			// Hiển thị kết quả truy vấn

			// 8. Hiển thị kết quả truy vấn
			for (Staff user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findOne(String username, String password) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.id=:id AND o.password=:pw";
			// Tạo đối tượng truy vấn
			TypedQuery<Staff> query = em.createQuery(jpql,Staff.class);
			query.setParameter("id", username);
			query.setParameter("pw", password);
			// Truy vấn một thực thể
			Staff user = query.getSingleResult();
			// Hiển thị kết quả truy vấn
			System.out.println(">>Fullname: " + user.getFullname());
			System.out.println(">>Is Admin: " + user.isAdmin());

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

//	public void findPage(int page, int size) {
//	
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
//
//		EntityManager em = emf.createEntityManager();
//		try {
//			em.getTransaction().begin(); 
//		
//
//	
//			String jpql = "SELECT o FROM User o";
//
//			TypedQuery<User> query = em.createQuery(jpql, User.class);
//			query.setFirstResult(page * size);
//			query.setMaxResults(size);
//
//			List<User> list = query.getResultList();
//
//			for (User user : list) {
//				System.out.println(">>Fullname: " + user.getFullname());
//				System.out.println(">>Is Admin: " + user.isAdmin());
//			}
//
//			// 8. Hiển thị kết quả truy vấn
//			for (User user : list) {
//				System.out.println(">>Fullname: " + user.getFullname());
//				System.out.println(">>Is Admin: " + user.isAdmin());
//			}
//
//			em.getTransaction().commit();
//			System.out.println(" thành công!");
//		} catch (Exception e) {
//		
//			em.getTransaction().rollback(); 
//			System.out.println(" thất bại!");
//		}
//		// 10. dù thành công hay không thành công nên đóng lại
//		em.close();
//		emf.close();
//
//	}


}
