package yeucau1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class TinhtongServlet
 */
@WebServlet({ "/tinhtong"})
public class TinhtongServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TinhtongServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/view/tinhtong.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		req.setCharacterEncoding("utf-8");
		//tinh tong
		double a = Double.parseDouble(req.getParameter("a"));
		double b = Double.parseDouble(req.getParameter("b"));
		double c = Double.parseDouble(req.getParameter("c"));
		double d = Double.parseDouble(req.getParameter("d"));
		double e = Double.parseDouble(req.getParameter("e"));
		double f = Double.parseDouble(req.getParameter("f"));
		
			double tinhtong = (a + b + c + d + e + f);		
			String uri = req.getRequestURI();
			if(uri.contains("tinhtong")){ 
				
				req.setAttribute("message", "Tong bang� : " + tinhtong);
			}
		 else {
				
		}
		

		req.getRequestDispatcher("/view/tinhtong.jsp").forward(req, resp);
	}

}
