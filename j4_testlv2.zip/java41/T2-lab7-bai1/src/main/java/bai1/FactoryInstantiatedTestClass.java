package bai1;

import org.testng.*;

import org.testng.annotations.*;

public class FactoryInstantiatedTestClass implements ITest{

	public String param;
	
	public FactoryInstantiatedTestClass(String param) {
		
		//chi ra parma 
		this.param = param;
	
		
	}
	public String getTestName() {
		//tra ve getClass 
		
		return getClass().getSimpleName()+ "-" + param;
		
	
		
	}
	
	@Factory
	public static Object[] create() {
		//tao quy trinh kiem thu tich hop
		return new Object[] {new FactoryInstantiatedTestClass("TestNG"),
				new FactoryInstantiatedTestClass("Reports")};
		
	}

	@Test
	public void f() {
		
		if(param.equals("Reports")) {
			//tra ve reports bat buoc la false
			Assert.assertTrue(false);
		}
	}

}
