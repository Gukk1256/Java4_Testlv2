package bai1;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.*;

public class testclass {
	@Test
	public void a1() {
		
	}
	@Parameters("param")
	@Test
	public void a2(String param) {

	}

	@Test(enabled=false)
	public void a3() {
		
	}

}

