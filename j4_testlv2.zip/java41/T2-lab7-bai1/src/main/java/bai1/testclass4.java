package bai1;

import org.testng.*;
import org.testng.annotations.*;

public class testclass4 {
	@Test
	public void e1() {
		
	}
	
	
	@Test
	public void e2() {
		Reporter.log("Method name is e2");
		
	}

	
	

}
