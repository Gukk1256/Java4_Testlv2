package bai1;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.*;
import org.testng.annotations.*;

public class testclass1 {
	@Test(groups="myGroup")

	public void t1() {
		AssertJUnit.assertTrue(false);
	}
	
	
	@Test(groups="myGroup")

	public void t2() {
		AssertJUnit.assertTrue(false);
	}
	
	@Test(groups="myGroup")
	public void t3() {
	
	}
	
	public void t4() {
		
	}
	
	@Test(dataProvider = "dp")
		public void t5(String param) {
			
		
		
	}
	
	@DataProvider
	private Object[][] dp(){
		return new Object[][] {{"one"},{"two"}};
	}
}
