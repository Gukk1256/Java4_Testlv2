package bai1;

import org.testng.*;
import org.testng.annotations.*;

public class testclass2 {
	@Test
	public void c1() {
		
	}
	
	
	@Test
	public void c2() {
		
	}
	
	@Test
	public void c3() {
	
	}
	
	@Test
	public void c4() {
		Assert.assertTrue(false);
		
	}
	

}
