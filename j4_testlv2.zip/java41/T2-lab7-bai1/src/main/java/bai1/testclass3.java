package bai1;

import org.testng.*;
import org.testng.annotations.*;

public class testclass3 {
	@Test(groups="myGroup")
	public void d1() {
		
	}
	
	
	@Test
	public void d2() {
		
	}

	
	

}
