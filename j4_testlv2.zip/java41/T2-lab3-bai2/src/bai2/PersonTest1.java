package bai2;


import org.junit.Rule;

import org.junit.Test;


public class PersonTest1 {
	
	
	
	@Test(expected = IllegalArgumentException.class)
	public void testExpectedException2() {
		new Person("Fpoly", -1);
	}
	
}
