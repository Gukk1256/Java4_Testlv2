package bai2;


import static org.junit.Assert.*;

import org.junit.Rule;

import org.junit.Test;


public class PersonTest2 {
	
	
	
	@Test
	public void testExpectedException3() {
		try {
			new Person("Fpoly", -1);
			fail("Should have thrown an IllegaArgumentException because age is invalid !");
			
		} catch (IllegalArgumentException ex) {
//			System.out.printf("LOi",ex) ;
			}
	}
	
}
