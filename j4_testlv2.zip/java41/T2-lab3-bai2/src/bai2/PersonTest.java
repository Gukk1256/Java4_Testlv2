package bai2;


import org.junit.Rule;

import org.junit.rules.ExpectedException;
import org.junit.Test;


public class PersonTest {

	
	@Rule
	public ExpectedException exception = ExpectedException.none();
	
	@Test
	public void testExceptedException() {
		exception.expect(IllegalArgumentException.class);
		new Person("Fpoly", -1);
		
	}
}
