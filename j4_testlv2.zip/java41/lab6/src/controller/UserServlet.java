package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import dao.UserDao;
import entities.User;

//@WebServlet ({"/index","/edit"})
@WebServlet({ "/user1/index", "/user1/edit/*", "/user1/create", "/user1/update", "/user1/delete" })
public class UserServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserDao dao = new UserDao();
		User user = new User();
		String uri = req.getRequestURI();

		if (uri.contains("edit")) {
			String id = uri.substring(uri.lastIndexOf("/") + 1);
			user = dao.findById(id);

		} else if (uri.contains("create")) {
			// insert
			try {
				BeanUtils.populate(user, req.getParameterMap());
				dao.create(user);
				req.setAttribute("message", "ThÃªm má»›i thÃ nh cÃ´ng");

			} catch (Exception e) {
				req.setAttribute("message", "ThÃªm má»›i tháº¥t báº¡i");
				e.printStackTrace();
			}

		} else if (uri.contains("update")) {
			// update
			try {
				BeanUtils.populate(user, req.getParameterMap());
				dao.update(user);
				req.setAttribute("message", "Cáº­p nháº­t thÃ nh cÃ´ng");

			} catch (Exception e) {
				req.setAttribute("message", "Cáº­p nháº­t tháº¥t báº¡i");
				e.printStackTrace();
			}

		} else if (uri.contains("delete")) {
			// delete
			try {
				String id1 = req.getParameter("id");
				dao.remove(id1);
				req.setAttribute("message", "XÃ³a thÃ nh cÃ´ng");

			} catch (Exception e) {
				req.setAttribute("message", "XÃ³a tháº¥t báº¡i");
				e.printStackTrace();
			}

		}

		req.setAttribute("form", user);
		req.setAttribute("items", dao.findAll());
		req.getRequestDispatcher("/view/user.jsp").forward(req, resp);

	}
}
