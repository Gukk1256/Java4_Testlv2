package controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.Video;
import utils.JpaUtils;

/**
 * Servlet implementation class Cau4Servlet
 */
@WebServlet("/Cau4Servlet")
public class Cau4Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cau4Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/view/cau4.jsp").forward(req, resp);
	}

	EntityManager em = JpaUtils.getEntityManager();
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean favorite = Boolean.parseBoolean(req.getParameter("favorite"));

		String jpql = "SELECT o FROM Video o WHERE o.favoriteCollection IS EMPTY";
		if(favorite) {
			jpql = "SELECT o FROM Video o WHERE o.favoriteCollection IS NOT EMPTY";
		}
		TypedQuery<Video> query = em.createQuery(jpql, Video.class);
		List<Video> list = query.getResultList();

		req.setAttribute("videos", list);

		req.getRequestDispatcher("/view/cau4.jsp").forward(req, resp);
	}

}
