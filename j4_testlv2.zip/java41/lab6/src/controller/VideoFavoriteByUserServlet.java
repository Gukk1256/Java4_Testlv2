package controller;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.*;
import utils.JpaUtils;

import java.util.*;

/**
 * Servlet implementation class VideoFavoriteByUserServlet
 */
@WebServlet("/VideoFavoriteByUserServlet")
public class VideoFavoriteByUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VideoFavoriteByUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/view/VideoFavoriteByUser.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	EntityManager em = JpaUtils.getEntityManager();
	
	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String videoId = req.getParameter("videoId");
		//3. Tìm những người sử dụng thích video (nhập video id)
		

		String jpql = "SELECT o.userId FROM Favorite o WHERE o.videoId.id=:vid";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("vid", videoId);
		List<User> list = query.getResultList();


		req.setAttribute("users", list);
		req.getRequestDispatcher("/view/VideoFavoriteByUser.jsp").forward(req, resp);
	}

}
