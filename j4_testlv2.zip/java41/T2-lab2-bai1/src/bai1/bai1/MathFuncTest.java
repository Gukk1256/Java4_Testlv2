package bai1.bai1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class MathFuncTest {
  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }


  @Test
  public void factorialTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void getCallsTest() {
    throw new RuntimeException("Test not implemented");
  
  }

  @Test
  public void plusTest() {
    throw new RuntimeException("Test not implemented");
  }
}
