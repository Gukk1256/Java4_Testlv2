/**
 * 
 */
package bai3;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Lenovo
 *
 */
public class TestRunner1 {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m1()}.
	 */
	@Test
	public void testM1() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m2()}.
	 */
	@Test
	public void testM2() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m3()}.
	 */
	@Test
	public void testM3() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m4()}.
	 */
	@Test
	public void testM4() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m5()}.
	 */
	@Test
	public void testM5() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m6()}.
	 */
	@Test
	public void testM6() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m7()}.
	 */
	@Test
	public void testM7() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link bai3.JunitAnnotationsExample#m8()}.
	 */
	@Test
	public void testM8() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#Object()}.
	 */
	@Test
	public void testObject() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#getClass()}.
	 */
	@Test
	public void testGetClass() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#hashCode()}.
	 */
	@Test
	public void testHashCode() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#equals(java.lang.Object)}.
	 */
	@Test
	public void testEquals() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#clone()}.
	 */
	@Test
	public void testClone() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#toString()}.
	 */
	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#notify()}.
	 */
	@Test
	public void testNotify() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#notifyAll()}.
	 */
	@Test
	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#wait()}.
	 */
	@Test
	public void testWait() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#wait(long)}.
	 */
	@Test
	public void testWaitLong() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#wait(long, int)}.
	 */
	@Test
	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link java.lang.Object#finalize()}.
	 */
	@Test
	public void testFinalize() {
		fail("Not yet implemented");
	}

}
