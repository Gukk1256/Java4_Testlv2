package lab2;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lab2.User;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/user.php")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		List<User> users = Arrays.asList(new User[]{
				new User("ngoctrinh", "111", true),
				new User("huy", "das", false),
				new User("Username 3", "Password 3", true)
				});
				req.setAttribute("message", "Quản lý người sử dụng!");
				req.setAttribute("form", users.get(0));
				req.setAttribute("items", users);
				
				
				req.getRequestDispatcher("/views/user/index.jsp").forward(req, resp);
	}
		

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}

}
