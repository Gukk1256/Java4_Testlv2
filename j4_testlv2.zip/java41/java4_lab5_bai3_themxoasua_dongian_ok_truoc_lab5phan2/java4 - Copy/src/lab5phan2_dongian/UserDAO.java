package lab5phan2_dongian;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class UserDAO {
//

	// 1. khai báo hàm
	public User create(User entity ) {

		User kq = new User();
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();		
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE


			// 7. Insert vào CSDL
			em.persist(entity);
			em.getTransaction().commit(); // 8.thêm thành công..commit... Chấp nhận kết quả thao tác
			System.out.println("Thêm mới thành công!");
			kq = entity;
		} catch (Exception e) {
			// 9. nếu thêm không thành thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println("Thêm mới thất bại!");
			kq = null;
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();
		return kq;
	}

	public User update(User entity) {

		User kq = null;
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();		
		try {
			
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE


			// 7. Cập nhật thực thể ===>> update
			em.merge(entity);

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println("Cập nhật thành công!");
			kq = entity;
		} catch (Exception e) {
			// 9. nếu Cập nhật không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println("Cập nhật thất bại!");
			kq = null;
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();
		return kq;
	}

	public User remove(String id) {

		User kq = null;
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE
			//

			// 5. tìm ra đối tượng nào có mã là TeoNV
			User entity = em.find(User.class, id);
			// 6. xóa đối tượng đó đi
			em.remove(entity);

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println("Xóa thành công!");
			kq = entity;
		} catch (Exception e) {
			// 9. nếu Xóa không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println("Xóa thất bại!");
			kq = null;
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();
		return kq;
	}

	public void findAll() {

		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// 5. Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o";
			// 6. Tạo đối tượng truy vấn
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			// 7. Truy vấn
			List<User> list = query.getResultList();
			// 8. Hiển thị kết quả truy vấn
			for (User user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findByRole(boolean role) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.admin=:role";
			// Tạo đối tượng truy vấn
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("role", role);
			// Truy vấn
			List<User> list = query.getResultList();
			// Hiển thị kết quả truy vấn

			// 8. Hiển thị kết quả truy vấn
			for (User user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findByKeyword(String keyword) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.fullname LIKE ?0";
			// Tạo đối tượng truy vấn
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter(0, keyword);
			// Truy vấn
			List<User> list = query.getResultList();
			// Hiển thị kết quả truy vấn

			// 8. Hiển thị kết quả truy vấn
			for (User user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findOne(String username, String password) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o WHERE o.id=:id AND o.password=:pw";
			// Tạo đối tượng truy vấn
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("id", username);
			query.setParameter("pw", password);
			// Truy vấn một thực thể
			User user = query.getSingleResult();
			// Hiển thị kết quả truy vấn
			System.out.println(">>Fullname: " + user.getFullname());
			System.out.println(">>Is Admin: " + user.isAdmin());

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

	public void findPage(int page, int size) {
		// 1. Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// 2. Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // 3. Bắt đầu Transaction
			// 4. VIẾT MÃ THAO TÁC CREATE

			// Câu lệnh truy vấn JPQL
			String jpql = "SELECT o FROM User o";
			// Tạo đối tượng truy vấn
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setFirstResult(page * size);
			query.setMaxResults(size);
			// Truy vấn
			List<User> list = query.getResultList();
			// Hiển thị kết quả truy vấn
			for (User user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			// 8. Hiển thị kết quả truy vấn
			for (User user : list) {
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.isAdmin());
			}

			em.getTransaction().commit(); // 8.thành công..commit... Chấp nhận kết quả thao tác
			System.out.println(" thành công!");
		} catch (Exception e) {
			// 9. nếu không thành công thì ...rollback..
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println(" thất bại!");
		}
		// 10. dù thành công hay không thành công nên đóng lại
		em.close();
		emf.close();

	}

}
