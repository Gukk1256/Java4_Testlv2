package lab5phan2_dongian;

public class JpaUtils {

}
