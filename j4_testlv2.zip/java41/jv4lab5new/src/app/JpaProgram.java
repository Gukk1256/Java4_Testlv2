package app;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.*;

import entities.User;

public class JpaProgram {

	public static void main(String[] args) {
		create();
		// update();
		// delete();
		// findAll();
		// findByRole(true);
		// findByKeyword(“Nguyễn”);
		// findOne(“TeoNV”, “123456”);
		// findPage(3, 5);
	}

	private static void create() {
		// Nạp persistence.xml và tạo EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// Tạo EntityManager để bắt đầu làm việc với CSDL
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); // Bắt đầu Transaction
			
			// MÃ THAO TÁC
			User entity = new User();
			// thêm dữ liệu cho đối tượng
			entity.setId("TeoNV");
			entity.setFullname("Nguyễn Văn Tèo");
			entity.setEmail("teonv@gmail.com");
			entity.setPassword("123456");
			
			/* entity.setAdmin(false); */
			// Insert vào CSDL
			em.persist(entity);

			em.getTransaction().commit(); // Chấp nhận kết quả thao tác
			System.out.println("Thêm mới thành công!");
		} catch (Exception e) {
			em.getTransaction().rollback(); // Hủy thao tác
			System.out.println("Thêm mới thất bại!");
		}
		em.close();
		emf.close();

	}

//	private static void update() {
//		// Truy vấn thực thể theo id
//		User entity = em.find(User.class, "TeoNV");
//		// Thay đổi thông tin thực thể
//		entity.setPassword("poly@2020");
//		entity.setAdmin(true);
//		// Cập nhật thực thể
//		em.merge(entity);
//	}
//
//	private static void delete() {
//		User entity = em.find(User.class, "TeoNV");
//		em.remove(entity);
//	}
//
//	private static void findAll() {
//		// Câu lệnh truy vấn JPQL
//		String jpql = "SELECT o FROM User o";
//		// Tạo đối tượng truy vấn
//		TypedQuery<User> query = em.createQuery(jpql, User.class);
//		// Truy vấn
//		List<User> list = query.getResultList();
//		// Hiển thị kết quả truy vấn
//		for(User user: list) {
//		System.out.println(">>Fullname: " + user.getFullname());
//		System.out.println(">>Is Admin: " + user.isAdmin());
//		}
//	}

	private static void findByRole(boolean a) {
	}

	private static void findByKeyword(String keywork) {
	}

	private static void findOne(String username, String password) {
	}

	private static void findPage(int page, int size) {
	}
}