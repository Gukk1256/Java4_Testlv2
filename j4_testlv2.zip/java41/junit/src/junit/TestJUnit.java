package junit;

import static org.testng.Assert.assertEquals;

import org.junit.Test;

public class TestJUnit {
	@Test 
	//kai bao ham , dung ham assertEquals de so sanh 2 mang co giong nhau khong
	public void testSetup() {
		String str= "I am done with Junit setup";
		assertEquals("I am done with Junit setup",str);
	}
	
	//chay test ben class Runner
	

}
