package junit;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {
	//tao ham Main thuc hien test 
	public static void main(String[] args) {
		Result result = JUnitCore.runClasses(TestJUnit.class);
		//tao vong lap 
		for(Failure failure : result.getFailures()) {
			System.out.println(failure.toString());
			
		} 
		//xuat ket qua 
		System.out.println("Result=="+result.wasSuccessful());
		
	}

}
