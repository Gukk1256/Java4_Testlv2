package app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.User;

public class JpaProgram {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		
		EntityManager em = emf.createEntityManager();
		try {
		em.getTransaction().begin(); 
		create();
		
		em.getTransaction().commit(); // 
		System.out.println("Thêm mới thành công!");
		} catch (Exception e) {
		em.getTransaction().rollback(); 
		System.out.println("Thêm mới thất bại!");
		}
		em.close();
		emf.close();

		}
			
		private static void create() {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
			
			EntityManager em = emf.createEntityManager();
			User entity = new User();
			entity.setId("TeoNV");
			entity.setFullname("Nguyễn Văn Tèo");
			entity.setEmail("teonv@gmail.com");
			entity.setPasswords("123456");
			
			em.persist(entity);
	


	}
		}


