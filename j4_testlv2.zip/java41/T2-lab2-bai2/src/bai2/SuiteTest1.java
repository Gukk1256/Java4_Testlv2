package bai2;

import static org.junit.Assert.assertEquals;
import org.junit.Test;




public class SuiteTest1 {
	public String message = "Fpoly";
	
	JUnitMessage junitMessage = new JUnitMessage(message);
	// @Test(expected = ArithmeticException.class)
	@Test
	public void testJUnitMessage() {
		System.out.println("Juint Message is printing");
		junitMessage.printMessage(message);
	}

	@Test
	public void testJUnitHiMessage() {
		message = "Hi!" + message;
		System.out.println("Junit Hi Message is printing");
		assertEquals(message, junitMessage.printMessage(message));
		System.out.println("Suite Test 2 is successful" + message);
	}
}
