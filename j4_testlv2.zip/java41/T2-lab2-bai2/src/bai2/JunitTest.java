package bai2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


//chay 2 class suite
@RunWith(Suite.class)
	@Suite.SuiteClasses({
		SuiteTest1.class,
		SuiteTest2.class
	})
	
public class JunitTest {

}
