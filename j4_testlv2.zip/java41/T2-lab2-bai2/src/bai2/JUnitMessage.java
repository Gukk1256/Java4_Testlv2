package bai2;

public class JUnitMessage {

	//khai bao them de chay code ben class test
	private String message;

	public JUnitMessage(String message) {
		this.message = message;
	}

	public String printMessage(String message) {
		System.out.println(message);
		return message;
	}

//	public void printMessage(String message) {
//		System.out.println(message);
//		int divide = 1 / 0;
//	}

	public String printMessageNew(String message) {
		System.out.println(message);
		return message;
	}

	public String printHiMessage(String message) {
		System.out.println(message);
		return message;
	}

}
