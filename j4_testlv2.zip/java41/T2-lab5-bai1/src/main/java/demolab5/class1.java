package demolab5;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class class1 {
	@Test
	public void verifyHomepageTitle() {
		//lay vi tri cua driver chrome
		System.setProperty("webdriver.chrome.driver","D:\\java41\\chromedriver.exe");
		//tao ra diver bang chrome drive
		WebDriver driver = new ChromeDriver();
		try {

			//tao duong dan visit 
		String url="https://www.youtube.com/";
		String title_website ="";
		String title_expected = "";
		driver.get(url);
		title_expected = driver.getTitle();	 
	
		//lenh tim ra name text field username nhap tai khoan vao standard_user
		
		driver.findElement(By.id("search")).sendKeys("Muộn màng" + Keys.ENTER);
	      
	    //lenh tim ra name text field passsword nhap matkhau vao secret_sauce
	      
	    
	    
	    	//thong bao connect thanh cong
	    		if(title_website.contentEquals(title_expected)) {
			System.out.println("Test pass");
		}else {
			//thong bao connect that bai
			System.out.println("Test Fail ");
		}
	    } finally {
	    	
	    	//dong link
	    //driver.close();
	    }
		
		
		
	}
}
