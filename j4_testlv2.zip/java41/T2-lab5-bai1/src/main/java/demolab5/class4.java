package demolab5;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Ignore;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class class4 {
	
	public WebDriver driver;

  @Test
  public void test() throws IOException {
	  driver.get("https://ap.poly.edu.vn/login/");	
	  File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	  //driver.findElement(By.className("recaptcha-checkbox-border")).click();
      FileUtils.copyFile(scrFile, new File("D:\\image1.png"));
  }
  @BeforeClass
  public void beforeClass() {
		System.setProperty("webdriver.chrome.driver","D:\\java41\\chromedriver.exe");
		driver = new ChromeDriver();
		
  }

  @AfterClass
  public void afterClass() {
//	  driver.close();
//	  driver.quit();
  }

}