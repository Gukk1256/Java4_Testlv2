package demolab5;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class fpoly {
	@Test
	public void verifyHomepageTitle() {
		//lay vi tri cua driver chrome
		System.setProperty("webdriver.chrome.driver","D:\\java41\\chromedriver.exe");
		//tao ra diver bang chrome drive
		WebDriver driver = new ChromeDriver();
		try {

			//tao duong dan visit
		String url="https://www.saucedemo.com/";
		String title_website ="saucedemo";
		String title_expected = "";
		driver.get(url);
		title_expected = driver.getTitle();	

		//lenh tim ra name text field username nhap tai khoan vao standard_user
	      driver.findElement(By.name("user-name")).sendKeys("standard_user" + Keys.ENTER);
	      
	    //lenh tim ra name text field passsword nhap matkhau vao secret_sauce
	      driver.findElement(By.name("password")).sendKeys("secret_sauce" + Keys.ENTER);
	      
	    //lenh tim ra name button login click dang nhap tai khoan
	    driver.findElement(By.name("login-button")).click();
	    
	    if(title_expected.contentEquals(title_website)) {
	    	//thong bao connect thanh cong
			System.out.println("Test pass");
		}else {
			//thong bao connect that bai
			System.out.println("Test Fail ");
		}
	    } finally {
	    	
	    	//dong link
	    //driver.close();
	    }
		
		
		
	}
}
