package lab3;


import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadServlet
 */

//1. nhớ thêm dòng này
@MultipartConfig
@WebServlet("/upload")
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// chuyển trang form.jsp 
		req.getRequestDispatcher("view/form.jsp").forward(req, resp);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		//1. đường dẫn thư mục tính từ gốc của website
		File dir = new File(req.getServletContext().getRealPath("/files"));
		//2. nếu chưa  có thư mục files thì tạo
		if(!dir.exists()) { // tạo nếu chưa tồn tại
			dir.mkdirs();
		}
		
		System.out.println("" + dir);  // xuất ra xem để biết thư mục năm ở đâu trên máy
		
		
		Part photo = req.getPart("photo_file"); 
		File photoFile = new File(dir, photo.getSubmittedFileName());
		photo.write(photoFile.getAbsolutePath()); 
		
		System.out.println("" + photoFile);
		
		Part doc = req.getPart("doc_file"); 
		File docFile = new File(dir, doc.getSubmittedFileName());
		doc.write(docFile.getAbsolutePath()); 
		
		Part img = req.getPart("photo_file"); 
		File imgFile = new File(dir, img.getSubmittedFileName());
		doc.write(imgFile.getAbsolutePath()); 

		
		req.setAttribute("img", photoFile);
		req.setAttribute("doc", docFile);
		
	
		req.getRequestDispatcher("/view/result.jsp").forward(req, resp);
		
		
	}

}
