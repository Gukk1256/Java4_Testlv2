package polyhcm1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestVatCalculator {
	//chạy test NG 
	@Test
	public void testGetVatCalculator() {
		VatCalculator calc = new VatCalculator();
		double expected = 10;
		Assert.assertEquals(calc.getVatOnAmout(100), expected);
		Assert.assertNotEquals(calc.getVatOnAmout(120), expected);
		
		
	}

}
