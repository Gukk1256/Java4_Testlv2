package polyhcm1;

public class VatCalculator {
	public double getVatOnAmout(double amount) {
		return amount * 0.1;
		//tạo class return amout , để tạo class test NG
	}

}
