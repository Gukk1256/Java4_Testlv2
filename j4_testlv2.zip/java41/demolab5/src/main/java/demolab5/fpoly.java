package demolab5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class fpoly {
	@Test
	public void verifyHomepageTitle() {
		System.setProperty("webdriver.chrome.driver","D:\\java41\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String url="https://ap.poly.edu.vn/";
		String title_website ="Hệ thống quản lý học tập Fpt Polytechnic";
		String title_expected = "";
		driver.get(url);
		title_expected = driver.getTitle();	
		if(title_expected.contentEquals(title_website)) {
			System.out.println("Test pass");
		}else {
			System.out.println("Test Fail ");
		}
		
	}
}
