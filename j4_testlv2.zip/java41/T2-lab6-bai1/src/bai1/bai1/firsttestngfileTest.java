package bai1.bai1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class firsttestngfileTest {
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
	  System.out.println("testClass : before test");
  }

  @AfterTest
  public void afterTest() {
  }


  @Test
  public void lauchBrowserTest() {
    System.out.println("testClass: Unit lauchBT");
  }

  @Test
  public void terminateBrowserTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void verifyHomepageTitleTest() {
    throw new RuntimeException("Test not implemented");
  }
}
