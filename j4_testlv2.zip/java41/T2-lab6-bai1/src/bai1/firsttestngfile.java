package bai1;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.*;

public class firsttestngfile {
	//tao baseUrl kieu du lieu String
	public String baseUrl = "https://www.saucedemo.com/";
	
	//tao driverPath chi ra vi tri luu 
	String driverPath ="D:\\java41\\chromedriver.exe";
	
	public WebDriver driver;
	
	@BeforeTest
	public void lauchBrowser() {
		//xuat dong launching chrome broser
		System.out.println("launching chrome broser");
		//
		System.setProperty("webdriver.chrome.driver", driverPath);

		
		driver = new ChromeDriver();
		driver.get(baseUrl);
	}
		
		@Test
		
		//ham test voi testNG
		public void verifyHomepageTitle() {
			String expectedTitle = "He thong quan ly hoc tap FPT";
			
			String actualTitle = driver.getTitle();
			Assert.assertEquals(actualTitle, expectedTitle);
		}
		@AfterTest
		public void terminateBrowser() {
			//dong lai khi hoan thanh
			driver.close();
		
	}

}
