package poly;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestLog {
	@Test
  public static void main(String[] args) {
	  
    WebDriver driver = new ChromeDriver();
    try {
      // Navigate to Url
      driver.get("https://www.saucedemo.com/");

      // Enter text "q" and perform keyboard action "Enter"
      driver.findElement(By.name("user-name")).sendKeys("standard_user" + Keys.ENTER);
      driver.findElement(By.name("password")).sendKeys("secret_sauce" + Keys.ENTER);
    driver.findElement(By.tagName("login-button")).click();
    } finally {
    
    }
  }
}

