package poly;

import java.util.*;

import org.openqa.selenium.*;

public class SaveTestNGResultToExcel {
	public WebDriver driver;
	public UIMap uimap;
	public UIMap datafile;
	public String workingDir;
	
	//HSSFWorkbook workbook;
	
	//HSSFSheet sheet;
	
	Map<String, Object[]> TestNGResult;
	//public static String driverPath 
	
	
	
	
	
	
   
	
}