package lab2;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TamGiacServlet
 */
//@WebServlet("/TamGiacServlet")

@WebServlet({ "/tam-giac", "/dien-tich", "/chu-vi" })
public class TamGiacServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TamGiacServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	// khi chạy sẽ xử lý hàm sau :
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		// 1. chuyển qua trang tam-giac.jsp
		req.getRequestDispatcher("/view/tam-giac.jsp").forward(req, resp);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		//1. lấy lại giá trị của các controls
		double a = Double.parseDouble(req.getParameter("a"));
		double b = Double.parseDouble(req.getParameter("b"));
		double c = Double.parseDouble(req.getParameter("c"));
		
		
		if ((a + b > c) && (a + c > b) && (b + c > a)) {
			// thực hiện tính diện tích hoạt chu vi ở đây
			double chuVi = (a + b + c); //2. tính chu vi
			
			String uri = req.getRequestURI(); //3. lấy uri
			//4. nếu người dùng click vào nút tính diện tích
			if(uri.contains("dien-tich")) { // [Tính diện tích].Click
				double dienTich = Math.sqrt(chuVi * (a + b - c) * (a + c - b) * (b + c - a))/4;
				req.setAttribute("message", "Diện tích của tam giác là " + dienTich);
			}
			else{ // [Tính chu vi].Click
				//5. ngược lại là click vào nút tính vi
				req.setAttribute("message", "Chu vi của tam giác là " + chuVi);
			}
					
		} else {
			req.setAttribute("message", "Không thỏa mãn các cạnh của một tam giác!");
		}
		
		//6. chuyển qua trang tam-giac.jsp
		req.getRequestDispatcher("/view/tam-giac.jsp").forward(req, resp);

		
	}

}
