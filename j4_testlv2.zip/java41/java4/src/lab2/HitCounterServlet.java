package lab2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HitCounterServlet
 */
@WebServlet("/HitCounterServlet")
public class HitCounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HitCounterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    //1. khai báo biến đếm count
    int count;
    Path path = Paths.get("d:/temp/count.txt");

	public void init(ServletConfig config) throws ServletException {
		//1. đọc số trong file count.txt lên biến count
		
		try {
			count = Integer.parseInt(Files.readAllLines(path).get(0));			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		//1. lưu biến đếm count xuống lại file count.txt
		
		try {
			//2. nhớ ép biến count qua kiểu String trước khi lưu nhé.
			Files.write(path, String.valueOf(count).getBytes(), StandardOpenOption.WRITE);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		    //1. tăng biến đếm lên 1
			count++;
			//2. gán biến đếm vào thuộc tính
			req.setAttribute("count", count);
			//3. chuyểnt qua trang 
			req.getRequestDispatcher("/view/hit-counter.jsp").forward(req, resp);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
