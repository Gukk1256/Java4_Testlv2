package lab3;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// mã đọc cookie đã ghi nhớ ở đây
		// đọc giá trị của cookie
		String username = CookieUtils.get("username", req);
		String password = CookieUtils.get("password", req);
		// chuyển sang login.jsp để hiển thị lên form
		req.setAttribute("username", username);
		req.setAttribute("password", password);

		req.getRequestDispatcher("/view/login.jsp").forward(req, resp);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		// đọc tham số form đăng nhập
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String remember = req.getParameter("remember");
		// kiểm tra tài khoản đăng nhập
		if(!username.equalsIgnoreCase("huy")) {
			req.setAttribute("message", "Sai tên đăng nhập!");
		}
		else if(password.length() < 3) {
			req.setAttribute("message", "Sai mật khẩu!");
		}
		else {
			if(password.equalsIgnoreCase("111"))
			{
				req.setAttribute("message", "Đăng nhập thành công!");
			// ghi nhớ hoặc xóa tài khoản đã ghi nhớ bằng cookie
				int hours = (remember == null) ? 0 : 30*24; // 0 = xóa
				CookieUtils.add("username", username, hours, resp);
				CookieUtils.add("password", password, hours, resp);
			}
		}
		
		
		// chuyển trang
		req.getRequestDispatcher("/view/login.jsp").forward(req, resp);
		
	}

}
