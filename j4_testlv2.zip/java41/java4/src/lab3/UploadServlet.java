package lab3;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadServlet
 */


//1. nhớ thêm dòng này nhé... khi xử lý upload file
@MultipartConfig
@WebServlet("/upload")
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//1. chuyển qua trang form.jsp
		req.getRequestDispatcher("/view/upload/form.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//1. đường dẫn vật lý của thư mục tính từ gốc của website
		File dir = new File(req.getServletContext().getRealPath("/files"));
		if(!dir.exists()) { // tạo nếu chưa tồn tại thư mục files
			dir.mkdirs();  //2. tạo thư mục files
		}
		
		//NHỚ XUẤT ĐƯỜNG DẪN THƯ MỤC FILES RA NHÉ
		System.out.println("" + dir);
		
		
		// lưu các file upload vào thư mục files
		Part photo = req.getPart("photo_file"); //3. lấy file hình
		File photoFile = new File(dir, photo.getSubmittedFileName()); 
		//4. lưu hình xuống thư mục files
		photo.write(photoFile.getAbsolutePath());
		
		Part doc = req.getPart("doc_file"); // file tài liệu
		File docFile = new File(dir, doc.getSubmittedFileName());
		doc.write(docFile.getAbsolutePath()); // lưu hình xuống thư mục files

		//5. gán vào thuộc tính ......chia sẻ cho result.jsp để hiển thị
		req.setAttribute("img", photoFile);
		req.setAttribute("doc", docFile);
		
		//6. chuyển qua trang result.jsp
		req.getRequestDispatcher("/view/upload/result.jsp").forward(req, resp);
		
	}

}
