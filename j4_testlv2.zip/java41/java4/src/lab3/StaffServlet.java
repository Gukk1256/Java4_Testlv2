package lab3;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DateTimeConverter;

import entities.Staff;

/**
 * Servlet implementation class StaffServlet
 */
@MultipartConfig
@WebServlet("/StaffServlet")
public class StaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StaffServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/view/staff/form.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		try {
			// Định dạng thời gian nhập vào
			DateTimeConverter dtc = new DateConverter(new Date());
			dtc.setPattern("MM/dd/yyyy"); 
			ConvertUtils.register(dtc, Date.class);
			
			
			//cau3
			
			// đường dẫn thư mục tính từ gốc của website
			File dir = new File(req.getServletContext().getRealPath("/files"));
			if(!dir.exists()) { // tạo nếu chưa tồn tại
				dir.mkdirs();
			}
			// lưu các file upload vào thư mục files
			Part photo = req.getPart("photo_file"); // file hình
			File photoFile = new File(dir, photo.getSubmittedFileName());
			photo.write(photoFile.getAbsolutePath());			
			
			
			//
			
			Staff staff = new Staff();
			// Lấy tên file upload đưa vào bean staff
			staff.setPhoto(photoFile.getName());
			
			// Đọc tham số vào các thuộc tính của bean staff
			BeanUtils.populate(staff, req.getParameterMap());
			
			// Chia sẻ với result.jsp
			req.setAttribute("bean", staff);
			
			//5. chuyển trang
			req.getRequestDispatcher("/view/staff/result.jsp").forward(req, resp);			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
